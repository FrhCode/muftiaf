

<?php $__env->startSection('content'); ?>
<div><?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
<!--News Section-->
<section class="section news">
    <div class="container">
        <h2 style="font-weight: bold; color: black !important;">Gubernur Jabar: PSBB di Jawa Barat Diperpanjang Hingga 29 Mei</h2>
        <span><em>20 Mei 2020, 23:21 WIB</em></span>
        <div class="text-center" style="margin: 6rem 0 !important;">
            <img src="<?php echo e(asset('images/isi3.jpg')); ?>" alt="news-image" style="width: 100%; height: auto; margin-bottom: 10px;">
            <br>
            <span><em>suaraindonesianews.com</em></span>
        </div>

        <p class="lead text-justify">
            Bandung, CNBC Indonesia – PSBB (Pembatasan Sosial Berskala Besar) tingkat provinsi di Jawa Barat telah diperpanjang hinggu Jumat, 29 Mei 2020. Dengan itu, setiap daerah diberikan kebijakan untuk menentukan persentase maksimal pergerakan masyarakat selama PSBB.
            <br>
            <br>
            “Kami juga mendapati kerawanan euforia dari Idul Fitri, maka kami sepakat gugus tugas untuk melanjutkan PSBB provinsi sampai tanggal 9 Mei 2020,” ujar Gubernur Jabar Ridwan Kamil dalam jumpa pers di Gedung Pakuan, Bandung.
            <br>
            <br>
            Hasil evaluasi PSBB tingkat provinsi di Jawa Barat memang menunjukkan tren positif dengan penurunan jumlah penularan Covid-19. Hal itu dapat dilihat dari rata-rata penambahan kasus per hari, yaitu 40 kasus per hari pada April 2020 turun menjadi 21 kasus per hari setelah PSBB digalakkan.
            <br>
            <br>
            Tingkat kematian di Jawa Barat pun menurut dari tujuh jiwa menjadi empat jiwa per hari. Sementara tingkat kesembuhan mencapai dua kali lipat. Dan, pasien yang dirawat mengalami penurunan sebanyak 160 pasien dari 430 pasien.
            <br>
            <br>
            Tak hanya itu, reproduksi penularan Covid-19 mencapai indeks 3 di Jawa Barat menurun menjadi indeks 1.
            <br>
            <br>
            Menjelang lebaran, terjadi kenaikan lalu lintas hingga 30 persen selama PSBB, dan minggu ini naik menuju 40 persen dikarenakan banyak warga yang tidak bisa menahan diri keluar rumah dan berbelanja menurut Kang Emil (sapaan akrab Ridwan Kamil).
            <br>
            <br>
            Sementara itu Kapolda Jabar, Rudy Sufahriadi mengatakan bahwa Polda Jabar gencar menyosialiasikan kepada masyarakat untuk tetap berada di rumah apabila tidak ada kepentingan.
        </p>
        <span><em>Sumber : CNBC Indonesia</em></span>
        <br>
        <span><em>Dipublikasikan oleh : Muhammad Iqbal</em></span>
        <br>
        <span><em>Editor : Ahmad Mufti F.R, Nabil M</em></span>
        <hr style="border-width: 2px !important;">
        <a href="/berita" style="font-size: 1.6rem;">< Go Back</a>
    </div>
 </section>
 <!--News Section END-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/pages/isiberita/isi3.blade.php ENDPATH**/ ?>