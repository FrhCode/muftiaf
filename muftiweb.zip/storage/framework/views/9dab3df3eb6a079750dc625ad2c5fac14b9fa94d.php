

<?php $__env->startSection('content'); ?>
<div><?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
<!--News Section-->
<section class="section news-index">
    <div class="container">
        <!--News Header-->
        <h2 class="news-header">Daftar Berita</h2>
        <!--News Header END-->

        <?php if(count($news) > 0): ?>
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="news-list">
                <a href="/berita/<?php echo e($item->id); ?>">
                    <div class="card card-site2">
                         <div class="col-12">
                                <div class="card-body" style="color: white !important;">
                                    <h3 style="font-weight: bold;"><?php echo e($item->title); ?></h3>
                                    <hr>
                                    <span><em><?php echo e($item->created_at->format('d M Y - H:i')); ?></em></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <h3 style="color: #367384; ">Tidak Ada Berita :(</h3>
        <?php endif; ?>
    </div>
 </section>
 <!--News Section END-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/pages/berita.blade.php ENDPATH**/ ?>