<footer class="footer">
    <div class="footer-top section">
        <div class="container">
        <div class="row">
            <div class="footer-col col-md-6">
            <h5>My Location</h5>
            <p>Limbangan Street West Java 44186 Indonesia.<br>
                0812 2171 2620 / 0822 6214 9895<br>
                r.muftiahmadf@gmail.com</p>
            </div>
            <div class="footer-col col-md-3">
            <h5>Services We Offer</h5>
            <p>
            <ul>
                <li><a href="#">Football Strategy</a></li>
                <li><a href="#">Websites</a></li>
                <li><a href="#">Caligraphy</a></li>
                <li><a href="#">Social Experiment</a></li>
                <li><a href="#">User Experience</a></li>
            </ul>
            </p>
            </div>
            <div class="footer-col col-md-3">
            <h5>Share with Love</h5>
            <ul class="footer-share">
                <li><a href="https://www.facebook.com/Muftiahmadfauzi"><i class="fa fa-facebook"></i></a></li>
                <li><a href="https://www.instagram.com/rmuftiaf"><i class="fa fa-instagram"></i></a></li>
                <li><a href="https://wa.me/6282262149895"><i class="fa fa-whatsapp"></i></a></li>
            </ul>
            </div>
        </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/inc/footer.blade.php ENDPATH**/ ?>