

<?php $__env->startSection('content'); ?>
<div><?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
<!--News Section-->
<section class="section news">
    <div class="container">
        <h2 style="font-weight: bold; color: black !important;">Berita Terbaru Virus Corona (Covid-19), Rabu, 20 Mei 2020 : Jumlah Pasien Positif Terus Bertambah</h2>
        <span><em>20 Mei 2020, 22:02 WIB</em></span>
        <div class="text-center" style="margin: 6rem 0 !important;">
            <img src="../images/isi1.jpg" alt="news-image" style="width: 100%; height: auto; margin-bottom: 10px;">
            <br>
            <span><em>antarkabarid.wordpress.com</em></span>
        </div>

        <p class="lead text-justify">
            Jubir (Juru Bicara) Pemerintah Penanganan Covid-19 Achmad Yurianto menyampaikan berita terbaru mengenai pasien positif Virus Corona. Dan hasilnya, pasien Covid-19 di Indonesia terus bertambah dan menghawatirkan.
            <br>
            <br>
            Pada hari ini, Rabu 20 Mei 2020, sebanyak 693 orang dinyatakan positif terkena Covid-19. Sedangkan untuk jumlah keseluruhan mancanegara lebih dari 4 juta orang di 216 negara, terpapar Covid-19 ini. Disadur dari WHO (covid19.go.id).
            <br>
            <br>
            “Sehingga totalnya menjadi 19.189 orang,” ujar Yurianto melalui konferensi pers daring di Graha BNPB Jakarta tepat hari ini. Dan juga berdampak pada penurunan angka kejahatan, menurut Kombes Pol. Asep Adi Saputra selaku Humas BNPB (bnpb.go.id).
            <br>
            <br>
            Total secara keseluruhan pasien sembuh dan negatif Covid-19 saat ini adalah 4.575 orang. Dan, pasien yang dirawat sebanyak 13.372 orang. (kompas.com).
            <br>
            <br>
            Sebelumnya, Achmad Yurianto memaparkan ada penambahan jumlah pasien sembuh sebanyak 143 orang, sejak kemarin. Jadi, total pasien yang sembuh sebanyak 4.467 orang.
            <br>
            <br>
            Yuri menambahkan, jumlah pasien positif berjumlah 486 orang, dan dari total sebanyak lebih dari 693 kasus dari berbagai pelosok negeri.
        </p>
        <span><em>Sumber : Liputan6.com</em></span>
        <br>
        <span><em>Dipublikasikan oleh : Rita Ayuningtyas (Reporter News Liputan6.com)</em></span>
        <br>
        <span><em>Editor : Ahmad Mufti F.R, Nabil M</em></span>
        <hr style="border-width: 2px !important;">
        <a href="/berita" style="font-size: 1.6rem;">Go Back</a>
    </div>
 </section>
 <!--News Section END-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/pages/isi1.blade.php ENDPATH**/ ?>