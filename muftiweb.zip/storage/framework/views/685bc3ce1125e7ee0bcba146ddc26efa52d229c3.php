

<?php $__env->startSection('content'); ?>
<div><?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
<!--News Section-->
<section class="section news">
    <div class="container">
        <h2 style="font-weight: bold; color: black !important;">Pemanfaatan Sinar Ultraviolet untuk Membasmi Virus Corona pada Kereta Bawah Tanah di New York</h2>
        <span><em>20 Mei 2020, 22:44 WIB</em></span>
        <div class="text-center" style="margin: 6rem 0 !important;">
            <img src="<?php echo e(asset('images/isi2.jpg')); ?>" alt="news-image" style="width: 100%; height: auto; margin-bottom: 10px;">
            <br>
            <span><em>www.koran-jakarta.com</em></span>
        </div>

        <p class="lead text-justify">
            WASHINGTON DC, KOMPAS.com – Para pejabat di Kota New York, Amerika Serikat melakukan program pensterilisasi mobil dan kereta bawah tanah sebagai percontohan menggunakan sinar ultraviolet (UV) pada Selasa, 19 Mei 2020 kemarin (ABC News).
            <br>
            <br>
            “Sepengetahuan kami, ini merupakan percontohan pertama yang dilakukan”, kata Patrick Foye selaku Kepala CEO Otoritas Transportasi Metropolitan (MTA) pada konferensi pers.
            <br>
            <br>
            Kepada media, Foye menjelaskan bahwa teknologi UV bekerja dengan efektif dalam mensterilkan ruangan-ruangan di rumah sakit.
            <br>
            <br>
            Menurutnya, ia tak ingin menyesatkan siapa pun tentang fungsi dari sinar UV. Namun, ia juga menjelaskan bahwa itu (UV) merupakan teknologi baru yang menjanjikan.
            <br>
            <br>
            Fungsi dari sinar ultraviolet sendiri dapat membunuh kuman dalam bentuk radiasi elektromagnetik.
            <br>
            <br>
            Senada dengan yang disampaikan oleh David Brenner sebagai direktur Pusat Penelitian Radiologi di Universitas Columbia, bahwa sinar UV sangat ampuh dalam membunuh virus dan bakteri. Berdasarkan penelitian lebih dari 100 tahun.
            <br>
            <br>
            Brenner menuturkan bahwa para ilmuwan yang bekerja di laboratorium, yang berlangsung di Columbia. Telah menemukan sampel SARS CoV-2 dan virus Covid-19 pada sinar UV untuk mengukur efektifitasnya dalam membunuh virus. Dan hasilnya, tepat seperti sebelumnya, bahwa sinar UV sangat efektif untuk membunuh virus itu.
            <br>
            <br>
            Gubernur New York, Andrew Cuomo telah mengumumkan penutupan sistem kereta bawah tanah di New York. Cuomo berusaha mensterilkan kereta bawah tanah dengan mengirimkan pasukan disinfektan kecil setiap malam untuk polisi, pekerja sosial dan perawat.
            <br>
            <br>
            Foye mengatakan bahwa proses tersebut menghabiskan biaya “ratusan juta dolar” dan dapat dihemat menggunakan program sinar UV, dengan cara memasang lampu, menutup pintu dan menyalakannya.
            <br>
            <br>
            Mark Dowd selaku Kepala Inovasi MTA menyebutkan bahwa para pekerja akan mulai menggunakan alat sterilisasi sinar UV pada pekan depan. MTA sendiri akan menghabiskan sekitar 1 juta dolar AS (sekitar 14 miliar rupiah) untuk membeli 150 lampu UV dari perusahaan start-up bernama Puro.

        </p>
        <span><em>Sumber : Kompas.com</em></span>
        <br>
        <span><em>Dipublikasikan oleh : Miranti Kencana Wirawan </em></span>
        <br>
        <span><em>Editor : Ahmad Mufti F.R</em></span>
        <hr style="border-width: 2px !important;">
        <a href="/berita" style="font-size: 1.6rem;">< Go Back</a>
    </div>
 </section>
 <!--News Section END-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/pages/isiberita/isi2.blade.php ENDPATH**/ ?>