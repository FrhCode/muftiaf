<!doctype html> 
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
<meta charset="utf-8">
<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Mufti-Website</title>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/flexslider.css">
<link rel="stylesheet" href="css/jquery.fancybox.css">
<link rel="stylesheet" href="css/main.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="css/font-icon.css">
<link rel="stylesheet" href="css/animate.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
</head>

<body>
<!-- header section -->
<section class="banner" role="banner">
  <header id="header">
    <div class="header-content clearfix"> <a class="logo" href="index.html">4M</a>
      <nav class="navigation" role="navigation">
        <ul class="primary-nav">
          <li><a href="#intro">Read More</a></li>
          <li><a href="#services">My Education</a></li>
          <li><a href="#works">Gallery</a></li>
          <li><a href="#teams">About us</a></li>
          <li><a href="#testimonials">Quotes</a></li>
        </ul>
      </nav>
      <a href="#" class="nav-toggle">Menu<span></span></a> </div>
  </header>
  <!-- banner text -->
  <div class="container">
    <div class="col-md-10 col-md-offset-1">
      <div class="banner-text text-center">
        <h1>I'm a bisnisMan</h1>
        <p>"Everything we do is designed, whether we're producing a magazine, a website, or a bridge. Design is really the creative invention that designs everything." -Henry Petroski</p>
        <a href="layout/List.html" class="btn btn-large primary-nav" role="navigation">Read More</a> </div>
      <!-- banner text --> 
    </div>
  </div>
</section>
<!-- header section --> 
<!-- intro section -->
<section id="intro" class="section intro">
  <div class="container">
    <div class="col-md-8 col-md-offset-2 text-center">
      <h3>Hello, This is My Business.</h3>
      <p>The content of website about foods (snack)</p>
      <a class="btn btn-primary" href="https://drive.google.com/file/d/1VO798fg0ldYFoCB8p0foxeX0NKcbMC3D/view?usp=sharing" target="blank">Download Portfolio</a>
    </div>
  </div>
</section>
<!-- intro section --> 
<!-- services section -->
<section id="services" class="services service-section">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-wallet"></span>
        <div class="services-content">
          <h5>SDN Limbangan Timur 1</h5>
          <p>2004-2010</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-gift"></span>
        <div class="services-content">
          <h5>SMPN 1 Limbangan</h5>
          <p>2010-2013</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-bargraph"></span>
        <div class="services-content">
          <h5>SMAN 1 Garut</h5>
          <p>2013-2016</p>
        </div>
      </div>
      <div class="col-md-3 col-sm-6 services text-center"> <span class="icon icon-grid"></span>
        <div class="services-content">
          <h5>UIN Sunan Gunung Djati Bandung</h5>
          <p>2017-Sekarang</p>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- services section --> 
<!-- work section -->
<section id="works" class="works section no-padding">
  <div class="container-fluid">
    <div class="row no-gutter">
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work-1.jpg" class="work-box"> <img src="images/work-1.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Map</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work2.jpg" class="work-box"> <img src="images/work-2.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Chocolate</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work-3.jpg" class="work-box"> <img src="images/work-3.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Hot</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work-4.jpg" class="work-box"> <img src="images/work-4.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Solo</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work5.jpg" class="work-box"> <img src="images/work-5.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Snacks</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work-6.jpg" class="work-box"> <img src="images/work-6.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Order</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work-7.jpg" class="work-box"> <img src="images/work-7.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Jakarta</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
      <div class="col-lg-3 col-md-6 col-sm-6 work"> <a href="images/work-8.jpg" class="work-box"> <img src="images/work-8.jpg" alt="">
        <div class="overlay">
          <div class="overlay-caption">
            <h5>Kaligrafi</h5>
            <p>RMAF</p>
          </div>
        </div>
        <!-- overlay --> 
        </a> </div>
    </div>
  </div>
</section>
<!-- work section --> 
<!-- our team section -->
<section id="teams" class="section teams">
  <div class="container">
    <div class="row text-center">
        <div class="person"><img src="images/team-1.jpg" alt="" class="img-responsive img-circle">
          <div class="person-content">
            <h4>4M Snack</h4>
            <h5 class="role">Bandung</h5>
            <p>"Semua yang kami lakukan dirancang, apakah kami memproduksi majalah, situs web, atau jembatan. Desain sebenarnya adalah penemuan kreatif yang merancang segalanya." -Henry Petroski. </p>
          </div>
          <ul class="social-icons clearfix">
            <li><a href="https://www.facebook.com/Muftiahmadfauzi"><span class="fa fa-facebook"></span></a></li>
            <li><a href="https://www.instagram.com/rmuftiaf"><span class="fa fa-instagram"></span></a></li>
            <li><a href="https://wa.me/6282262149895"><span class="fa fa-whatsapp"></span></a></li>
          </ul>
        </div>
    </div>
  </div>
</section>
<!-- our team section --> 
<!-- Testimonials section -->
<section id="testimonials" class="section testimonials no-padding">
  <div class="container-fluid">
    <div class="row no-gutter">
      <div class="flexslider">
        <ul class="slides">
          <li>
            <div class="col-md-12">
              <blockquote>
                <h1>"God will not give a trial above the ability of his people" </h1>
                <p>Hj. Enden N, Quote</p>
              </blockquote>
            </div>
          </li>
          <li>
            <div class="col-md-12">
              <blockquote>
                <h1>"Our greatest glory is not never falling, but in rising every time we fall." </h1>
                <p>Confusius, Quote.</p>
              </blockquote>
            </div>
          </li>
          <li>
            <div class="col-md-12">
              <blockquote>
                <h1>"Kenali musuhmu, kenali dirimu. Kau akan memenangkan semua pertarungan." </h1>
                <p>Sun Tzu, Quote</p>
              </blockquote>
            </div>
          </li>
          <li>
            <div class="col-md-12">
              <blockquote>
                <h1>"Tiap tempat akan menjadi sempit bila dimasukkan sesuatu ke dalamnya, kecuali tempat ilmu. Ia akan bertambah luas, jika dimasukkan ilmu ke dalamnya." </h1>
                <p>Sayyidina Ali ra, Quote</p>
              </blockquote>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</section>
<!-- Testimonials section --> 

<!-- Footer section -->
<footer class="footer">
  <div class="footer-top section">
    <div class="container">
      <div class="row">
        <div class="footer-col col-md-6">
          <h5>My Location</h5>
          <p>Limbangan Street West Java 44186 Indonesia.<br>
            0812 2171 2620 / 0822 6214 9895<br>
            r.muftiahmadf@gmail.com</p>
        </div>
        <div class="footer-col col-md-3">
          <h5>Services We Offer</h5>
          <p>
          <ul>
            <li><a href="#">Football Strategy</a></li>
            <li><a href="#">Websites</a></li>
            <li><a href="#">Caligraphy</a></li>
            <li><a href="#">Social Experiment</a></li>
            <li><a href="#">User Experience</a></li>
          </ul>
          </p>
        </div>
        <div class="footer-col col-md-3">
          <h5>Share with Love</h5>
          <ul class="footer-share">
            <li><a href="https://www.facebook.com/Muftiahmadfauzi"><i class="fa fa-facebook"></i></a></li>
            <li><a href="https://www.instagram.com/rmuftiaf"><i class="fa fa-instagram"></i></a></li>
            <li><a href="https://wa.me/6282262149895"><i class="fa fa-whatsapp"></i></a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- footer top --> 
  
</footer>
<!-- Footer section --> 
<!-- JS FILES --> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/jquery.flexslider-min.js"></script> 
<script src="js/jquery.fancybox.pack.js"></script> 
<script src="js/retina.min.js"></script> 
<script src="js/modernizr.js"></script> 
<script src="js/main.js"></script> 
<script type="text/javascript" src="js/jquery.contact.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/pages/test.blade.php ENDPATH**/ ?>