

<?php $__env->startSection('content'); ?>
<div><?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
<!--News Section-->
<section class="section news">
    <div class="container">
        <h2 style="font-weight: bold; color: black !important;"><?php echo e($news->title); ?></h2>
        <span><em><?php echo e($news->created_at->format('d M Y - H:i')); ?></em></span>
        <!--<div class="text-center" style="margin: 6rem 0 !important;">
            <img src="<?php echo e(asset('images/isi1.jpg')); ?>" alt="news-image" style="width: 100%; height: auto; margin-bottom: 10px;">
            <br>
            <span><em><?php echo e($news->source); ?></em></span>
        </div>-->
        <?php echo $news->body; ?>

        <hr style="border-width: 2px !important;">
        <a href="/berita" style="font-size: 1.6rem;">< Go Back</a>
    </div>
 </section>
 <!--News Section END-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\muftiweb\resources\views/pages/isiberita/isi.blade.php ENDPATH**/ ?>