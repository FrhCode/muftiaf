<header id="header">
    <div class="header-content clearfix"> <a class="logo" href="/">C-19</a>
        <nav class="navigation navbar" role="navigation">
            <ul class="primary-nav">
                <li><a href="/">Beranda</a></li>
                <li><a href="/berita">Berita</a></li>
                <li><a href="/statistik">Data & Statistik</a></li>
                <li><a href="/fakta">Fakta Corona</a></li>
                <li><a href="https://www.ayobandung.com/">ayobandung.com</a></li>
                <li><a href="https://covid19.go.id/">covid19.go.id</a></li>
            </ul>
        </nav>
        <a href="#" class="nav-toggle">Menu<span></span></a> 
    </div> 
</header>